# NeuroCore AI Keyboard — Etapa 9
**NÃO TERMINADO — correções estáticas no JNI; build real ainda não executado.**

## Correções aplicadas
- Corrigido um erro de sintaxe: o include de `<mutex>` estava com os caracteres literais `\\n` na linha.
- Removida a chamada explícita a `llama_sampler_accept()` após `llama_sampler_sample()`. A implementação atual do llama.cpp já chama `accept` internamente durante a amostragem; a chamada adicional duplicava a atualização do sampler.
- Adicionada validação para prompt vazio e prompt que ultrapassa o contexto configurado.
- Limitada a geração nativa a no máximo 256 tokens por chamada, para evitar pedidos exagerados ao bridge.

## Conferência com a API atual
As funções `llama_model_load_from_file`, `llama_init_from_model`, `llama_model_free`, `llama_tokenize`, `llama_vocab_is_eog`, `llama_token_to_piece`, `llama_memory_clear`, `llama_batch_get_one` e `llama_decode` são compatíveis com a interface pública consultada do llama.cpp. A implementação atual de `llama_sampler_sample` também executa `llama_sampler_accept` internamente.

Referências consultadas:
- https://github.com/ggml-org/llama.cpp/blob/master/include/llama.h
- https://github.com/ggml-org/llama.cpp/blob/master/src/llama-sampler.cpp
- https://github.com/ggml-org/llama.cpp/blob/master/docs/build.md

## Limites desta etapa
- Nenhum APK foi gerado.
- Nenhuma compilação CMake/Gradle foi executada.
- Ainda é necessário compilar contra um commit específico do llama.cpp e resolver eventuais erros que só aparecem no NDK.
- Ainda não foi testada a autorização root, SELinux, instalação do IME ou inserção de texto no aparelho.

**Não instalar como módulo KernelSU ainda.** Este ZIP é código-fonte de desenvolvimento.


Etapa 10 fixa a dependência llama.cpp no commit `3b4d6ab`; veja README-ETAPA-10.md.
