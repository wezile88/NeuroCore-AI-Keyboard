# NeuroCore AI Keyboard — Etapa 12
**NÃO TERMINADO — validação de empacotamento preparada; build real não executado.**

## Alterações
- Atualizado `module.prop` para a etapa 12.
- `assemble-and-pack.sh` agora busca a revisão fixada do llama.cpp antes do build.
- O empacotamento só ocorre após APK existir e passar na verificação estrutural.
- Novo `validate-apk.sh` verifica `AndroidManifest.xml`, `classes.dex` e a biblioteca JNI ARM64.
- Scripts do módulo permanecem executáveis.

## Compilar e empacotar
Em um ambiente com Java, Gradle, Android SDK, NDK e CMake configurados:
1. Execute `cd android-bridge`.
2. Configure `ANDROID_HOME` e instale a plataforma SDK exigida pelo projeto.
3. Execute `./check-build-env.sh`.
4. Volte à raiz do projeto e execute `./assemble-and-pack.sh`.

## Limitações
- Nenhum APK foi criado nesta etapa: este ambiente não tem Android SDK/NDK nem Gradle configurados.
- A validação do APK é estrutural, não um teste de execução.
- Ainda faltam testes reais do IME, permissão root, SELinux, leitura do GGUF, geração e descarga de RAM no aparelho.
- O APK de debug não deve ser tratado como versão final de distribuição.

## Instalação
Não instale este ZIP de fontes. Só o ZIP gerado com sucesso por `assemble-and-pack.sh`, contendo o APK validado, poderá ser testado como módulo KernelSU.
