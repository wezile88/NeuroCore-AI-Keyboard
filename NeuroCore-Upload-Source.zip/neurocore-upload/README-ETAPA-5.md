# NeuroCore AI Keyboard — Etapa 5
**NÃO TERMINADO — integração JNI inicial preparada; ainda precisa compilar e testar.**

## Regra do modelo (conforme solicitado)
O usuário baixa o GGUF e coloca em:
`/data/adb/modules/neurocore_ai_keyboard/models/`

O módulo não baixa nem inclui modelos. O bridge procura o primeiro arquivo `.gguf` dessa pasta.

## O que entrou
- Interface com ações Carregar IA / Gerar / Descarregar.
- `ModelController`: carrega somente após toque e descarrega ao sair do campo/teclado.
- Contrato JNI Kotlin.
- Código C++ inicial usando API llama.cpp.
- CMake e script `fetch-llama.sh` para obter o código-fonte oficial do llama.cpp durante a compilação.

## Compilação
1. Execute `android-bridge/fetch-llama.sh`.
2. Compile com Android Studio/Gradle, NDK e CMake instalados.
3. Corrija eventuais diferenças de API do commit atual do llama.cpp.
4. Gere o APK e use o `assemble-and-pack.sh` da raiz para empacotar o módulo.

## Limitações reais
- Não foi compilado nesta etapa: este ambiente não tem Android SDK/NDK configurado.
- O C++ usa APIs do llama.cpp que podem mudar entre versões; exige build e teste.
- A geração é uma implementação inicial simples, sem template de chat específico do modelo, streaming ou controle avançado de contexto.
- Contexto 512 e 2–4 threads são valores conservadores iniciais, não uma promessa de desempenho.
- O modelo GGUF precisa ser compatível com a versão do llama.cpp compilada e caber na memória disponível.
- O carregamento e descarregamento precisam ser validados no POCO X6 Pro e na ROM instalada.

**Não instale este ZIP de fontes como módulo KernelSU.** Ele é o pacote de desenvolvimento. O ZIP KernelSU só será produzido quando houver APK compilado.
