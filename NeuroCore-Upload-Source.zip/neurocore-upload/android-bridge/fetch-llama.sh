#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
TARGET="$ROOT/app/src/main/cpp/third_party/llama.cpp"
REPO="https://github.com/ggml-org/llama.cpp.git"
PIN="3b4d6ab"

if [ -d "$TARGET/.git" ]; then
  CURRENT="$(git -C "$TARGET" rev-parse --short=7 HEAD 2>/dev/null || true)"
  if [ "$CURRENT" = "$PIN" ]; then
    echo "llama.cpp já está no commit fixado $PIN"
    exit 0
  fi
  echo "Já existe um checkout em $TARGET, mas ele não está no commit $PIN." >&2
  echo "Por segurança, não vou sobrescrever alterações locais. Faça backup e remova essa pasta antes de executar novamente." >&2
  exit 3
fi

mkdir -p "$(dirname "$TARGET")"
git init "$TARGET"
git -C "$TARGET" remote add origin "$REPO"
git -C "$TARGET" fetch --depth 1 origin "$PIN"
git -C "$TARGET" checkout --detach FETCH_HEAD
ACTUAL="$(git -C "$TARGET" rev-parse --short=7 HEAD)"
if [ "$ACTUAL" != "$PIN" ]; then
  echo "Commit inesperado: $ACTUAL (esperado $PIN)" >&2
  exit 4
fi
echo "llama.cpp fixado em $ACTUAL"
