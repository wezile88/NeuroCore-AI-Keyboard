#include <jni.h>
#include <android/log.h>
#include <algorithm>
#include <cstdint>
#include <limits>
#include <mutex>
#include <string>
#include <vector>
#include "llama.h"

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "NeuroCore", __VA_ARGS__)

static std::mutex g_mutex;
static llama_model* g_model = nullptr;
static llama_context* g_ctx = nullptr;
static const llama_vocab* g_vocab = nullptr;
static bool g_backend_initialized = false;

static std::string jstr(JNIEnv* env, jstring value) {
    if (value == nullptr) return {};
    const char* chars = env->GetStringUTFChars(value, nullptr);
    if (chars == nullptr) return {};
    std::string out(chars);
    env->ReleaseStringUTFChars(value, chars);
    return out;
}

static void unload_locked() {
    if (g_ctx != nullptr) {
        llama_free(g_ctx);
        g_ctx = nullptr;
    }
    if (g_model != nullptr) {
        llama_model_free(g_model);
        g_model = nullptr;
    }
    g_vocab = nullptr;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_neurocore_bridge_NeuroCoreNative_loadModel(
        JNIEnv* env, jobject, jstring path, jint contextSize, jint threads) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_ctx != nullptr) return JNI_TRUE;

    const std::string modelPath = jstr(env, path);
    if (modelPath.empty() || contextSize < 64 || threads < 1) {
        LOGE("Parâmetros inválidos para carregar o modelo");
        return JNI_FALSE;
    }

    if (!g_backend_initialized) {
        llama_backend_init();
        g_backend_initialized = true;
    }

    const auto mparams = llama_model_default_params();
    g_model = llama_model_load_from_file(modelPath.c_str(), mparams);
    if (g_model == nullptr) {
        LOGE("Falha ao abrir modelo: %s", modelPath.c_str());
        return JNI_FALSE;
    }

    auto cparams = llama_context_default_params();
    cparams.n_ctx = static_cast<uint32_t>(contextSize);
    cparams.n_threads = static_cast<int32_t>(threads);
    cparams.n_threads_batch = static_cast<int32_t>(threads);
    g_ctx = llama_init_from_model(g_model, cparams);
    if (g_ctx == nullptr) {
        LOGE("Falha ao criar contexto llama.cpp");
        llama_model_free(g_model);
        g_model = nullptr;
        return JNI_FALSE;
    }

    g_vocab = llama_model_get_vocab(g_model);
    if (g_vocab == nullptr) {
        LOGE("Vocabulário do modelo indisponível");
        unload_locked();
        return JNI_FALSE;
    }
    return JNI_TRUE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_neurocore_bridge_NeuroCoreNative_isLoaded(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    return (g_ctx != nullptr && g_vocab != nullptr) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_neurocore_bridge_NeuroCoreNative_unloadModel(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    unload_locked();
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_neurocore_bridge_NeuroCoreNative_generate(
        JNIEnv* env, jobject, jstring promptJ, jint maxTokens) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_ctx == nullptr || g_vocab == nullptr) return env->NewStringUTF("");

    const std::string prompt = jstr(env, promptJ);
    if (prompt.empty() || prompt.size() > static_cast<size_t>(std::numeric_limits<int32_t>::max()))
        return env->NewStringUTF("");

    const int32_t promptBytes = static_cast<int32_t>(prompt.size());
    const int32_t needed = llama_tokenize(g_vocab, prompt.c_str(), promptBytes,
                                           nullptr, 0, true, true);
    if (needed == std::numeric_limits<int32_t>::min() || needed >= 0)
        return env->NewStringUTF("");

    const int32_t tokenCount = -needed;
    const uint32_t contextTokens = llama_n_ctx(g_ctx);
    if (tokenCount <= 0 || static_cast<uint32_t>(tokenCount) >= contextTokens)
        return env->NewStringUTF("");

    std::vector<llama_token> tokens(static_cast<size_t>(tokenCount));
    const int32_t encoded = llama_tokenize(g_vocab, prompt.c_str(), promptBytes,
                                            tokens.data(), tokenCount, true, true);
    if (encoded < 0 || encoded > tokenCount) return env->NewStringUTF("");

    llama_memory_clear(llama_get_memory(g_ctx), true);
    auto batch = llama_batch_get_one(tokens.data(), encoded);
    if (llama_decode(g_ctx, batch) != 0) {
        LOGE("Falha ao processar o prompt");
        return env->NewStringUTF("");
    }

    llama_sampler* sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    if (sampler == nullptr) return env->NewStringUTF("");
    llama_sampler_chain_add(sampler, llama_sampler_init_greedy());

    const uint32_t remaining = contextTokens - static_cast<uint32_t>(encoded);
    const int32_t requested = std::max(1, std::min(static_cast<int32_t>(maxTokens), 256));
    const int32_t tokenLimit = static_cast<int32_t>(std::min<uint32_t>(remaining, static_cast<uint32_t>(requested)));
    std::string output;

    for (int32_t i = 0; i < tokenLimit; ++i) {
        const llama_token id = llama_sampler_sample(sampler, g_ctx, -1);
        if (llama_vocab_is_eog(g_vocab, id)) break;

        std::vector<char> piece(256);
        int32_t pieceSize = llama_token_to_piece(g_vocab, id, piece.data(),
                                                  static_cast<int32_t>(piece.size()), 0, true);
        if (pieceSize < 0) {
            const int64_t required = -static_cast<int64_t>(pieceSize);
            if (required > 0 && required <= 1024 * 1024) {
                piece.resize(static_cast<size_t>(required));
                pieceSize = llama_token_to_piece(g_vocab, id, piece.data(),
                                                  static_cast<int32_t>(piece.size()), 0, true);
            }
        }
        if (pieceSize > 0 && static_cast<size_t>(pieceSize) <= piece.size())
            output.append(piece.data(), static_cast<size_t>(pieceSize));

        if (i + 1 < tokenLimit) {
            llama_token nextToken = id;
            batch = llama_batch_get_one(&nextToken, 1);
            if (llama_decode(g_ctx, batch) != 0) {
                LOGE("Falha durante a geração");
                break;
            }
        }
    }

    llama_sampler_free(sampler);
    return env->NewStringUTF(output.c_str());
}

extern "C" JNIEXPORT void JNICALL JNI_OnUnload(JavaVM*, void*) {
    std::lock_guard<std::mutex> lock(g_mutex);
    unload_locked();
    if (g_backend_initialized) {
        llama_backend_free();
        g_backend_initialized = false;
    }
}
