package com.neurocore.bridge

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.Executors

class NeuroCoreImeService : InputMethodService() {
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var closing = false
    private var status: TextView? = null
    private var prompt: EditText? = null

    private fun report(message: String) {
        runOnUiThread { if (!closing) status?.text = message }
    }

    override fun onCreateInputView(): View {
        closing = false
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            setBackgroundColor(Color.rgb(10, 10, 10))
        }
        root.addView(TextView(this).apply {
            text = "NEUROCORE  •  IA LOCAL"
            setTextColor(Color.WHITE)
            textSize = 14f
        })
        status = TextView(this).apply {
            text = "Modelo descarregado"
            setTextColor(Color.LTGRAY)
        }
        root.addView(status)

        prompt = EditText(this).apply {
            hint = "Digite seu comando ou texto"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setBackgroundColor(Color.rgb(32, 32, 32))
            minLines = 2
        }
        root.addView(prompt)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(Button(this).apply {
            text = "Carregar IA"
            setOnClickListener {
                report("Carregando modelo…")
                worker.execute { report(ModelController.loadOnDemand(this)) }
            }
        })
        actions.addView(Button(this).apply {
            text = "Gerar"
            setOnClickListener {
                val input = prompt?.text?.toString().orEmpty()
                if (input.isBlank()) {
                    report("Digite um texto primeiro.")
                } else {
                    report("Gerando…")
                    worker.execute {
                        val result = ModelController.generate(input)
                        if (result.isNotBlank()) {
                            runOnUiThread {
                                if (!closing) {
                                    currentInputConnection?.commitText(result, 1)
                                    status?.text = "Texto inserido."
                                }
                            }
                        } else report("Sem resultado. Verifique se o modelo está carregado.")
                    }
                }
            }
        })
        actions.addView(Button(this).apply {
            text = "Descarregar"
            setOnClickListener {
                report("Descarregando…")
                worker.execute {
                    ModelController.unload()
                    report("Modelo descarregado.")
                }
            }
        })
        root.addView(actions)
        root.addView(Button(this).apply {
            text = "Inserir texto digitado"
            setOnClickListener {
                val value = prompt?.text?.toString().orEmpty()
                if (value.isNotEmpty()) currentInputConnection?.commitText(value, 1)
            }
        })
        return root
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        if (finishingInput) {
            closing = true
            worker.execute { ModelController.unload() }
        }
    }

    override fun onDestroy() {
        closing = true
        worker.execute { ModelController.unload() }
        worker.shutdown()
        super.onDestroy()
    }
}
