package com.neurocore.bridge

import android.content.Context
import java.io.File

/**
 * O GGUF continua armazenado no diretório do módulo KernelSU.
 * Como o sandbox do Android bloqueia acesso direto a /data/adb, o bridge
 * pede root no momento do carregamento e copia o arquivo para filesDir.
 */
object ModelController {
    private const val MODULE_MODEL_DIR =
        "/data/adb/modules/neurocore_ai_keyboard/models"

    @Volatile private var loaded = false
    private var privateModel: File? = null

    private fun shellQuote(value: String): String =
        "'" + value.replace("'", "'\\''") + "'"

    private fun runRoot(command: String): Pair<Int, String> {
        val process = ProcessBuilder("su", "-c", command)
            .redirectErrorStream(true)
            .start()
        val output = process.inputStream.bufferedReader().use { it.readText() }
        return process.waitFor() to output.trim()
    }

    private fun locateModelAsRoot(): String? {
        val cmd = "find ${shellQuote(MODULE_MODEL_DIR)} -maxdepth 1 -type f -iname '*.gguf' -print -quit"
        val (code, output) = runRoot(cmd)
        if (code != 0 || output.isBlank()) return null
        if (!output.startsWith("$MODULE_MODEL_DIR/")) return null
        val name = output.substringAfterLast('/')
        if (!name.matches(Regex("[A-Za-z0-9._-]+\\.gguf", RegexOption.IGNORE_CASE))) return null
        return output
    }

    @Synchronized fun loadOnDemand(context: Context): String {
        if (loaded && NeuroCoreNative.isLoaded()) return "Modelo já carregado."
        val source = try { locateModelAsRoot() } catch (e: Exception) {
            return "Não foi possível obter root pelo KernelSU: ${e.message}"
        } ?: return "Nenhum GGUF encontrado em $MODULE_MODEL_DIR"

        val modelDir = File(context.filesDir, "models")
        if (!modelDir.exists() && !modelDir.mkdirs()) return "Falha ao criar pasta privada do modelo."
        val target = File(modelDir, source.substringAfterLast('/'))

        val copyCommand = "cp ${shellQuote(source)} ${shellQuote(target.absolutePath)} && " +
            "chown ${context.applicationInfo.uid}:${context.applicationInfo.uid} ${shellQuote(target.absolutePath)} && " +
            "chmod 600 ${shellQuote(target.absolutePath)}"
        val (copyCode, copyOutput) = try { runRoot(copyCommand) } catch (e: Exception) {
            return "Falha ao copiar modelo com root: ${e.message}"
        }
        if (copyCode != 0 || !target.isFile || target.length() == 0L) {
            return "Falha ao copiar GGUF para a área privada: $copyOutput"
        }

        val threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 4)
        val ok = NeuroCoreNative.loadModel(target.absolutePath, 512, threads)
        loaded = ok
        privateModel = if (ok) target else null
        if (!ok) target.delete()
        return if (ok) "Modelo carregado: ${target.name}"
        else "llama.cpp não conseguiu abrir o GGUF. Confira formato, arquitetura e memória."
    }

    @Synchronized fun generate(prompt: String): String {
        if (!loaded || !NeuroCoreNative.isLoaded()) return ""
        return NeuroCoreNative.generate(prompt, 128)
    }

    @Synchronized fun unload() {
        if (loaded || NeuroCoreNative.isLoaded()) NeuroCoreNative.unloadModel()
        loaded = false
        privateModel?.delete()
        privateModel = null
    }
}
