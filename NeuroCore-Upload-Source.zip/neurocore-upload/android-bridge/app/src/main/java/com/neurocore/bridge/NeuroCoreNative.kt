package com.neurocore.bridge

/**
 * JNI contract for the llama.cpp backend.
 * Native library is built from the llama.cpp source in app/src/main/cpp/third_party/llama.cpp.
 */
object NeuroCoreNative {
    init { System.loadLibrary("neurocore_jni") }

    external fun loadModel(modelPath: String, contextSize: Int, threads: Int): Boolean
    external fun generate(prompt: String, maxTokens: Int): String
    external fun unloadModel()
    external fun isLoaded(): Boolean
}
