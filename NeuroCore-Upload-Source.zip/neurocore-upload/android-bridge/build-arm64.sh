#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

if [ -z "${ANDROID_NDK:-}" ] && [ -n "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ]; then\n  SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT}}"\n  ANDROID_NDK="$(find "$SDK/ndk" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | sort -V | tail -n 1)"\n  export ANDROID_NDK\nfi\n: "${ANDROID_NDK:?Defina ANDROID_NDK ou instale o NDK pelo SDK Manager}"
test -f "$ANDROID_NDK/build/cmake/android.toolchain.cmake" || {
  echo "Toolchain do Android NDK não encontrada"; exit 2;
}
if [ ! -f app/src/main/cpp/third_party/llama.cpp/CMakeLists.txt ]; then
  ./fetch-llama.sh
fi

cmake -S app/src/main/cpp -B app/.cxx/arm64-release \
  -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a \
  -DANDROID_PLATFORM=android-29 \
  -DCMAKE_BUILD_TYPE=Release \
  -DGGML_NATIVE=OFF \
  -DGGML_OPENMP=OFF \
  -DGGML_LLAMAFILE=OFF \
  -DLLAMA_OPENSSL=OFF \
  -DGGML_CPU_KLEIDIAI=ON

cmake --build app/.cxx/arm64-release --config Release --parallel
echo "Build nativo ARM64 concluído. Agora compile o APK pelo Gradle/Android Studio."
