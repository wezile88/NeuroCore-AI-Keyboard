#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

echo "== NeuroCore: verificação do ambiente =="
command -v java >/dev/null || { echo "ERRO: Java/JDK ausente."; exit 2; }
JAVA_LINE="$(java -version 2>&1 | head -n 1)"
echo "$JAVA_LINE"
JAVA_MAJOR="$(java -XshowSettings:properties -version 2>&1 | awk '/java.specification.version =/ {print $3; exit}')"
JAVA_MAJOR="${JAVA_MAJOR#1.}"
if [ -z "$JAVA_MAJOR" ] || [ "$JAVA_MAJOR" -lt 17 ]; then
  echo "ERRO: Android Gradle Plugin 8.7.3 requer JDK 17 ou superior."
  exit 3
fi

SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [ -z "$SDK" ] || [ ! -d "$SDK" ]; then
  echo "ERRO: defina ANDROID_HOME ou ANDROID_SDK_ROOT para o SDK Android."
  exit 4
fi
[ -d "$SDK/platforms/android-35" ] || {
  echo "ERRO: instale Android SDK Platform 35."
  exit 5
}
[ -d "$SDK/build-tools" ] || {
  echo "ERRO: Android SDK Build-Tools ausentes."
  exit 6
}
[ -d "$SDK/ndk" ] || {
  echo "ERRO: Android NDK ausente no SDK."
  exit 7
}
[ -d "$SDK/cmake" ] || {
  echo "ERRO: CMake do Android SDK ausente."
  exit 8
}

command -v gradle >/dev/null || {
  echo "ERRO: Gradle ausente. Use Gradle 8.9 ou superior compatível com AGP 8.7.3."
  exit 9
}
GRADLE_LINE="$(gradle --version | grep -m1 '^Gradle ')"
echo "$GRADLE_LINE"
GRADLE_VERSION="${GRADLE_LINE#Gradle }"
GRADLE_MAJOR="${GRADLE_VERSION%%.*}"
GRADLE_REST="${GRADLE_VERSION#*.}"
GRADLE_MINOR="${GRADLE_REST%%.*}"
if [ "$GRADLE_MAJOR" -lt 8 ] || { [ "$GRADLE_MAJOR" -eq 8 ] && [ "$GRADLE_MINOR" -lt 9 ]; }; then
  echo "ERRO: AGP 8.7.3 requer Gradle 8.9 ou superior."
  exit 10
fi

echo "Ambiente básico compatível detectado."
echo "Próximo: ./fetch-llama.sh e depois ../assemble-and-pack.sh"
