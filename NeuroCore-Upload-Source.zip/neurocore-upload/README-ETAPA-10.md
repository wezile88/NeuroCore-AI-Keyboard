# NeuroCore AI Keyboard — Etapa 10
**NÃO TERMINADO — dependência fixada; build não executado.**

## Alteração desta etapa
- O script `android-bridge/fetch-llama.sh` não clona mais `master`.
- Ele busca e faz checkout destacado do commit `3b4d6ab` do repositório oficial `ggml-org/llama.cpp`.
- O script verifica o commit final e recusa sobrescrever um checkout existente que esteja em outra revisão.
- `LLAMA_CPP_LOCK.txt` registra a origem e a revisão fixada.

A revisão `3b4d6ab` aparece no histórico oficial do projeto em 10/11/2026. A documentação oficial fornece a configuração CMake Android ARM64 e as opções KleidiAI/NDK usadas nas etapas anteriores.

Fontes:
- https://github.com/ggml-org/llama.cpp/commit/3b4d6ab
- https://github.com/ggml-org/llama.cpp/blob/master/docs/build.md

## Como executar
1. Use um ambiente com Git, Android NDK, CMake e Gradle compatíveis.
2. Execute `./fetch-llama.sh` dentro de `android-bridge`.
3. Execute `./build-arm64.sh`.
4. Depois, rode o build Gradle do projeto Android.

## Limitações honestas
- Esta etapa fixa a dependência, mas não prova que o JNI compila com ela.
- Nenhuma compilação foi executada nesta sessão.
- Nenhum APK ou módulo KernelSU instalável foi gerado.
- O commit fixado é um snapshot reproduzível, não uma afirmação de que seja a versão mais recente ou a melhor para desempenho.
- O carregamento real do GGUF e a autorização root continuam exigindo teste no aparelho e na ROM usada.
