#!/usr/bin/env bash
set -euo pipefail
APK="${1:?Uso: ./validate-apk.sh caminho/app-debug.apk}"
[ -s "$APK" ] || { echo "APK ausente ou vazio"; exit 2; }
LIST="$(unzip -Z1 "$APK")"
for entry in AndroidManifest.xml classes.dex lib/arm64-v8a/libneurocore_jni.so; do
  printf '%s\n' "$LIST" | grep -Fxq "$entry" || {
    echo "APK inválido/incompleto: falta $entry"
    exit 3
  }
done
echo "Estrutura básica do APK confirmada (manifest, classes.dex e JNI ARM64)."
echo "Isto não comprova instalação, registro do IME ou execução do modelo."
