#!/system/bin/sh
MODDIR=${0%/*}
BASE=/data/adb/neurocore
mkdir -p "$BASE/logs" "$BASE/run"
mkdir -p "$MODDIR/models"
chmod 0755 "$MODDIR" "$MODDIR/models"
chmod 0700 "$BASE" "$BASE/logs" "$BASE/run"
