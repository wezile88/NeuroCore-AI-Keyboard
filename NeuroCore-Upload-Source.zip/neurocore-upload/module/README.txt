NeuroCore AI Keyboard — módulo KernelSU
NÃO TERMINADO: adicione NeuroCoreBridge.apk nesta pasta via assemble-and-pack.sh.
Ative o módulo e reinicie. Se o teclado não aparecer, consulte /data/adb/neurocore/logs/boot.log.
