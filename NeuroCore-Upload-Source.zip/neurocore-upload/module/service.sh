#!/system/bin/sh
MODDIR=${0%/*}
BASE=/data/adb/neurocore
mkdir -p "$BASE/logs" "$MODDIR/models"
chmod 0755 "$MODDIR/models"
{
  echo "=== NeuroCore Stage 7 ==="
  date
  echo "SDK=$(getprop ro.build.version.sdk)"
  echo "ABI=$(getprop ro.product.cpu.abi)"
  echo "Model directory: $MODDIR/models"
  echo "GGUF count: $(find "$MODDIR/models" -maxdepth 1 -type f -iname '*.gguf' 2>/dev/null | wc -l)"
} >> "$BASE/logs/boot.log" 2>&1
