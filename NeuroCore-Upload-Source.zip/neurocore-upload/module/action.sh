#!/system/bin/sh
APK=/system/app/NeuroCoreBridge/NeuroCoreBridge.apk
echo "NeuroCore AI Keyboard — diagnóstico"
echo "SDK: $(getprop ro.build.version.sdk)"
echo "ABI: $(getprop ro.product.cpu.abi)"
if [ -f "$APK" ]; then
  echo "APK: presente"
else
  echo "APK: AUSENTE"
fi
pm list packages 2>/dev/null | grep 'com.neurocore.bridge' || echo "Pacote não listado"
echo "Log: /data/adb/neurocore/logs/boot.log"
