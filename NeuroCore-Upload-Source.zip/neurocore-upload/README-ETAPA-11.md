# NeuroCore AI Keyboard — Etapa 11

**NÃO TERMINADO — endurecimento estático do JNI. Não é APK nem módulo instalável.**

## Auditoria da revisão fixada
A revisão `3b4d6ab` foi aberta diretamente no repositório oficial. O cabeçalho `include/llama.h` dessa revisão contém as declarações usadas pelo bridge: `llama_model_load_from_file`, `llama_init_from_model`, `llama_n_ctx`, `llama_vocab_is_eog`, `llama_tokenize`, `llama_token_to_piece`, `llama_batch_get_one`, `llama_decode` e as funções do sampler.

## Ajustes no JNI
- Validação de parâmetros e strings antes de chamar a biblioteca.
- Limite de geração respeita o espaço restante no contexto.
- Conversão de token aumenta o buffer quando a API informa que o espaço é insuficiente.
- Limpeza de contexto/modelo centralizada.
- Backend inicializado uma vez e liberado em `JNI_OnUnload`.
- Logs de erro para falhas de prompt e geração.

## Verificação realizada
- A revisão `3b4d6ab` foi confirmada no GitHub e o cabeçalho dessa revisão foi consultado.
- O arquivo JNI foi revisado estaticamente e o ZIP foi empacotado.
- A opção `GGML_CPU_KLEIDIAI` também foi confirmada no `ggml/CMakeLists.txt` da mesma revisão fixada.
- A tentativa de verificar o ambiente de build parou porque `ANDROID_HOME/ANDROID_SDK_ROOT` não está definido neste ambiente. Portanto, **nenhum build NDK/Gradle foi executado**.

## Limitações ainda abertas
- Compilar contra o checkout real do commit fixado e resolver qualquer erro de compilador/linker.
- Testar execução e descarga repetida de GGUF.
- Testar permissões root, SELinux, IME e inserção de texto na ROM do aparelho.
- Confirmar que o GGUF escolhido é suportado e cabe na memória disponível.
- Gerar o APK e só então integrá-lo ao ZIP KernelSU.

## Build
Em máquina com Android SDK, NDK, CMake e Gradle configurados:
1. `cd android-bridge`
2. `./fetch-llama.sh`
3. `./check-build-env.sh`
4. `gradle --no-daemon :app:assembleDebug`

A documentação Android NDK confirma que o toolchain CMake deve receber a ABI e o nível mínimo de API correspondentes ao aplicativo. A documentação llama.cpp também documenta o build `arm64-v8a` e as opções portáveis usadas aqui.
