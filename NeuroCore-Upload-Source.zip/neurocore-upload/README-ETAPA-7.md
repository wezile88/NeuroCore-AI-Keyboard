# NeuroCore AI Keyboard — Etapa 7
**NÃO TERMINADO — acesso ao GGUF pelo bridge preparado; exige compilação e teste com KernelSU.**

## Pasta do GGUF
O usuário coloca o arquivo `.gguf` em:
`/data/adb/modules/neurocore_ai_keyboard/models/`

O módulo não baixa nem inclui o modelo.

## Correção importante
Um processo Android comum não deve presumir que consegue ler `/data/adb/modules/...`. O bridge agora solicita root somente quando o usuário toca em **Carregar IA**, localiza um GGUF, copia para `filesDir/models` (área privada do bridge) e abre essa cópia com llama.cpp. Ao descarregar, libera o contexto nativo e apaga a cópia privada. O arquivo original dentro do módulo permanece intacto.

O primeiro pedido de root pode abrir uma confirmação do KernelSU. O usuário precisa autorizar. Se negar, o carregamento falha sem iniciar a inferência.

## Ainda falta
- Compilar e testar o APK com Android SDK/NDK/CMake.
- Confirmar o comportamento do `su -c` no KernelSU e SELinux da ROM.
- Confirmar que o módulo está instalado com ID `neurocore_ai_keyboard`.
- Validar GGUF compatível com a versão llama.cpp e medir RAM/latência.
- O bridge ainda não foi empacotado em APK; este arquivo é pacote de fontes, não instalável como módulo.

## Segurança/estabilidade
O código aceita apenas nomes simples de arquivo GGUF, usa caminhos entre aspas no shell e não executa conteúdo do modelo como comando. A autorização root é solicitada apenas no carregamento.
