# NeuroCore AI Keyboard — Etapa 4
**NÃO TERMINADO — integração/empacotamento preparado; APK ainda não compilado.**

Esta etapa organiza o módulo KernelSU para receber o APK interno do IME da Etapa 3 e inclui um script de empacotamento.

## Estrutura final prevista
O APK será colocado em `module/system/app/NeuroCoreBridge/NeuroCoreBridge.apk`. O Android reconhecerá o IME como componente do sistema após a ativação do módulo e reinicialização, sujeito à compatibilidade da ROM.

## Gerar o ZIP
1. Instale Android SDK/Android Studio e Gradle em um ambiente de compilação.
2. Compile `android-bridge` da Etapa 3: `gradle --no-daemon assembleDebug`.
3. Copie `android-bridge/app/build/outputs/apk/debug/app-debug.apk` para `module/system/app/NeuroCoreBridge/NeuroCoreBridge.apk`.
4. Execute `./assemble-and-pack.sh`.

O script interrompe o processo se o APK não existir. Ele não cria um APK falso.

## Limitações
- Ainda não há APK compilado dentro deste pacote.
- Ainda não há llama.cpp, JNI ou modelo GGUF.
- A instalação como app de sistema depende do mecanismo systemless da versão do KernelSU e da ROM. O script de diagnóstico verifica presença do pacote, mas não consegue garantir compatibilidade universal.
- Após ativar o módulo, confira em Configurações > Sistema > Idiomas e entrada > Teclado virtual. O caminho pode variar por ROM.
