# NeuroCore AI Keyboard — Etapa 13
**NÃO TERMINADO — portas de validação do build corrigidas; compilação real ainda não executada.**

## Correções desta etapa
- Alinhei `versionCode` e `versionName` do APK com a etapa 13.
- Corrigi a ordem de `check-build-env.sh`: agora ele não exige llama.cpp antes de `fetch-llama.sh`.
- Adicionei verificação de JDK 17+, Android SDK Platform 35, NDK, CMake e Gradle 8.9+.
- `assemble-and-pack.sh` executa a verificação antes de baixar dependências e compilar.
- O script auxiliar ARM64 tenta localizar automaticamente o NDK instalado no SDK.

## Por que esses requisitos
O projeto usa Android Gradle Plugin 8.7.3. A documentação oficial indica JDK 17 para AGP 8.x e Gradle 8.9 como versão mínima para AGP 8.7. <https://developer.android.com/build/jdks> <https://developer.android.com/build/releases/about-agp>

As opções CMake ARM64/KleidiAI seguem a documentação oficial do llama.cpp. <https://github.com/ggml-org/llama.cpp/blob/master/docs/build.md>

## Sequência de compilação
Dentro de `android-bridge`:
1. `./check-build-env.sh`
2. `./fetch-llama.sh`

Na raiz do projeto:
3. `./assemble-and-pack.sh`

## Estado real
- O ambiente atual não tem Gradle nem Android SDK configurados; portanto, não executei Gradle/CMake nem gerei APK.
- Não é um módulo KernelSU instalável enquanto não houver um APK validado dentro do pacote.
- A validação estrutural do APK não substitui testes de instalação, registro do IME, autorização root, SELinux, carregamento GGUF, geração e liberação de RAM.
