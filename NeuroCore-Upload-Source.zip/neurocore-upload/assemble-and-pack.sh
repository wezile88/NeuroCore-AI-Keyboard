#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
BRIDGE="$ROOT/android-bridge"
APK="$BRIDGE/app/build/outputs/apk/debug/app-debug.apk"
DEST="$ROOT/module/system/app/NeuroCoreBridge/NeuroCoreBridge.apk"
OUT="$ROOT/NeuroCore-AI-Keyboard-KernelSU.zip"

cd "$BRIDGE"
./check-build-env.sh

if [ ! -f app/src/main/cpp/third_party/llama.cpp/CMakeLists.txt ]; then
  ./fetch-llama.sh
fi

echo "Compilando APK debug ARM64..."
gradle --no-daemon :app:assembleDebug

[ -s "$APK" ] || { echo "ERRO: APK não foi produzido."; exit 11; }
"$ROOT/validate-apk.sh" "$APK"

mkdir -p "$(dirname "$DEST")"
cp "$APK" "$DEST"
chmod 0644 "$DEST"

cd "$ROOT/module"
rm -f "$OUT"
zip -qr "$OUT" .
echo "Módulo KernelSU empacotado: $OUT"
echo "APK debug. Faça os testes no aparelho; ainda não é versão de distribuição."
