# NeuroCore AI Keyboard — Etapa 6
**NÃO TERMINADO — correções de integração e execução assíncrona.**

## Ajustes desta etapa
- Removida a chamada `llama_sampler_accept`, que não aparece na API pública atual consultada do llama.cpp.
- Operações de carregar, gerar e descarregar passaram para uma fila de trabalho para não bloquear a interface do teclado.
- A geração foi centralizada no `ModelController`, com sincronização junto ao descarregamento.
- Adicionado verificador do ambiente Android SDK/NDK/CMake.

A API atual consultada mantém as funções usadas para carregar modelo, criar contexto, decodificar tokens e amostrar tokens. Consulte `include/llama.h` do upstream antes de atualizar o código: https://github.com/ggml-org/llama.cpp/blob/master/include/llama.h

## Modelo GGUF
O usuário baixa o GGUF e o coloca em:
`/data/adb/modules/neurocore_ai_keyboard/models/`

O módulo não baixa nem inclui o modelo.

## Teste obrigatório
1. Em ambiente com Android SDK, NDK, CMake e Gradle, execute `fetch-llama.sh`.
2. Execute `check-build-env.sh`.
3. Execute `gradle --no-daemon assembleDebug`.
4. Corrija qualquer erro de compilação reportado pela versão upstream clonada.
5. Teste carregar, gerar, descarregar, minimizar teclado e trocar de app no dispositivo real.

## Limitação
Não foi possível compilar neste ambiente porque não há Android SDK/NDK configurado. Portanto, esta etapa não confirma compatibilidade binária nem funcionamento em ROM real. Não instale este ZIP como módulo KernelSU; é pacote de fontes.
