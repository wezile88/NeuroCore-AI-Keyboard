# NeuroCore AI Keyboard — Etapa 8
**NÃO TERMINADO — configuração de build ARM64 preparada; compilação real não executada.**

## O que foi ajustado
- CMake agora define opções de compilação portável Android arm64-v8a.
- `GGML_NATIVE=OFF`, `GGML_OPENMP=OFF`, `GGML_LLAMAFILE=OFF` e `LLAMA_OPENSSL=OFF`.
- KleidiAI CPU habilitado como opção de otimização para ARM64.
- ABI Android limitada a `arm64-v8a`.
- Script `build-arm64.sh` para configurar e compilar o alvo nativo.

Essas opções seguem as instruções Android ARM64 da documentação oficial do llama.cpp:
https://github.com/ggml-org/llama.cpp/blob/master/docs/build.md

## Executar
Em ambiente com Android NDK, CMake e Git:
1. Defina `ANDROID_NDK` para a pasta do NDK.
2. Entre na pasta `android-bridge`.
3. Execute `./build-arm64.sh`.
4. Se a compilação nativa terminar, compile o APK com Gradle/Android Studio.

## O que esta etapa NÃO confirma
- Não foi executado build real neste ambiente.
- Não confirma que o código JNI atual compila contra o commit mais recente do llama.cpp.
- Não confirma instalação como app de sistema ou funcionamento de root/SELinux na ROM.
- Não inclui APK compilado, modelo GGUF, ou ZIP KernelSU pronto.

## Regra GGUF
O usuário baixa o arquivo e coloca em:
`/data/adb/modules/neurocore_ai_keyboard/models/`
O bridge solicita root no momento do carregamento e copia o arquivo para a área privada antes de abrir com llama.cpp.
